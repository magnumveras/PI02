/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.magnoveras;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.plaf.basic.BasicSliderUI;

/**
 *
 * @author magno.mveras
 */
public class Main {
    
    public static void criarGUI(){
        //Instância da Classe JFrame
        JFrame frame = new JFrame();
        
        //Tamanho minimo do frame
        //Dimension d = new Dimension(400,400);
        //frame.setMinimumSize(d);
        frame.setMinimumSize(new Dimension(400,400));
        
        //Método da classe para fechar Janela do programa
        JPanel panel = new JPanel();
        frame.setTitle("Aula 1 de Swing");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Nova label
        JLabel label = new JLabel("Olá mundo!");
        JLabel label2 = new JLabel("Aula Senac!");
        JLabel label3 = new JLabel("Aula Senac!");
        
        //Novo TextField
        JTextField textfield = new JTextField(10);
        
        //Novos Botões
        JButton botao = new JButton("Entrar");
        JButton botao2 = new JButton("Teste Listener");
        JButton botao3 = new JButton("Atribuir valor do TextField");
        //Listener
        ActionListener teste = new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                System.out.println("Clicou no botão!");
            }
        };
        
        botao.addActionListener(teste);
        
        botao2.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                System.out.println("Nova forma de Listener!");
            }
        });
        
        botao3.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                System.out.println("Teste: " + textfield.getText());
                JOptionPane.showMessageDialog(frame, "asdadasdasdasd");
                
            }
        });
        
        
        //Associa o Panel ao Pai frame
        frame.getContentPane().add(panel);
        
        //Associa os Labels junto ao Panel
        panel.add(label);
        panel.add(label2);  
        panel.add(label3);
        
        //Associa TextField junto ao Panel
        panel.add(textfield);
        
        //Associa Button junto ao Panel
        panel.add(botao);
        panel.add(botao2);
        panel.add(botao3);
        
        //Impede que a tela seja maximizada
        frame.setResizable(false);
        
        //para construir a interface
        frame.pack();
        
        //para mostrar a tela
        frame.setVisible(true);
    }
    
    public static void main(String[] args) {
        
        Runnable runnable = new Runnable() {
            public void run() {
                criarGUI();
            }
        };
        
        SwingUtilities.invokeLater(runnable);
    }
}
